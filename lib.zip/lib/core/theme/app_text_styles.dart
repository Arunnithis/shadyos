import 'package:flutter/material.dart';

class AppTextStyles {
  static const heading = TextStyle(fontSize: 24, fontWeight: FontWeight.bold);

  static const subHeading = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.w600,
  );

  static const body = TextStyle(fontSize: 16);
}
