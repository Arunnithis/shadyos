class Mission {
  final String id;
  final String title;
  final String category;

  final bool completed;

  final bool pinned;

  final DateTime createdAt;
}

  Mission copyWith({
    String? id,
    String? title,
    String? category,
    bool? completed,
  }) {
    return Mission(
      id: id ?? this.id,
      title: title ?? this.title,
      category: category ?? this.category,
      completed: completed ?? this.completed,
    );
  }
}
